# AutoExcel v0.2

A Python application to parse excel sheets, manipulate data and plot graphs. 
This app is developed for a specific Excel sheet format for analysing research data. 

