from distutils.core import setup

setup(
    name='AutoExcel',
    version='0.1',
    packages=['src'],
    url='',
    license='',
    author='Vignesh',
    author_email='swift2891@gmail.com',
    description='Parsing Excel documents and Manipulating values, plot graphs and so on.'
)
